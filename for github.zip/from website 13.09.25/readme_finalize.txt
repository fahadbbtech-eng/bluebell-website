Replace placeholder images in img/ with your real assets. Filenames must match exactly.
